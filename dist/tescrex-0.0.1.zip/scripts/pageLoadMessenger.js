// chrome.storage.sync.get('current', function (data) {
//   console.log(data);
//   if (data.current) {
//     chrome.runtime.sendMessage({ from: 'content_script', message: 'inject' });
//   }
// });
